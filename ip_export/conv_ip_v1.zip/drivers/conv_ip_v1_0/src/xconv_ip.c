// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xconv_ip.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XConv_ip_CfgInitialize(XConv_ip *InstancePtr, XConv_ip_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XConv_ip_Start(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XConv_ip_IsDone(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XConv_ip_IsIdle(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XConv_ip_IsReady(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XConv_ip_EnableAutoRestart(XConv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XConv_ip_DisableAutoRestart(XConv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_AP_CTRL, 0);
}

void XConv_ip_Set_in_r(XConv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_IN_R_DATA, (u32)(Data));
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_IN_R_DATA + 4, (u32)(Data >> 32));
}

u64 XConv_ip_Get_in_r(XConv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_IN_R_DATA);
    Data += (u64)XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_IN_R_DATA + 4) << 32;
    return Data;
}

void XConv_ip_Set_wgt(XConv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_WGT_DATA, (u32)(Data));
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_WGT_DATA + 4, (u32)(Data >> 32));
}

u64 XConv_ip_Get_wgt(XConv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_WGT_DATA);
    Data += (u64)XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_WGT_DATA + 4) << 32;
    return Data;
}

void XConv_ip_Set_bias(XConv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_BIAS_DATA, (u32)(Data));
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XConv_ip_Get_bias(XConv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_BIAS_DATA);
    Data += (u64)XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_BIAS_DATA + 4) << 32;
    return Data;
}

void XConv_ip_Set_mult(XConv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_MULT_DATA, (u32)(Data));
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_MULT_DATA + 4, (u32)(Data >> 32));
}

u64 XConv_ip_Get_mult(XConv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_MULT_DATA);
    Data += (u64)XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_MULT_DATA + 4) << 32;
    return Data;
}

void XConv_ip_Set_out8(XConv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_OUT8_DATA, (u32)(Data));
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_OUT8_DATA + 4, (u32)(Data >> 32));
}

u64 XConv_ip_Get_out8(XConv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_OUT8_DATA);
    Data += (u64)XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_OUT8_DATA + 4) << 32;
    return Data;
}

void XConv_ip_Set_out32(XConv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_OUT32_DATA, (u32)(Data));
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_OUT32_DATA + 4, (u32)(Data >> 32));
}

u64 XConv_ip_Get_out32(XConv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_OUT32_DATA);
    Data += (u64)XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_OUT32_DATA + 4) << 32;
    return Data;
}

void XConv_ip_Set_c_in(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_C_IN_DATA, Data);
}

u32 XConv_ip_Get_c_in(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_C_IN_DATA);
    return Data;
}

void XConv_ip_Set_h(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_H_DATA, Data);
}

u32 XConv_ip_Get_h(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_H_DATA);
    return Data;
}

void XConv_ip_Set_w(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_W_DATA, Data);
}

u32 XConv_ip_Get_w(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_W_DATA);
    return Data;
}

void XConv_ip_Set_c_out(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_C_OUT_DATA, Data);
}

u32 XConv_ip_Get_c_out(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_C_OUT_DATA);
    return Data;
}

void XConv_ip_Set_k(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_K_DATA, Data);
}

u32 XConv_ip_Get_k(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_K_DATA);
    return Data;
}

void XConv_ip_Set_stride(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_STRIDE_DATA, Data);
}

u32 XConv_ip_Get_stride(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_STRIDE_DATA);
    return Data;
}

void XConv_ip_Set_pad(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_PAD_DATA, Data);
}

u32 XConv_ip_Get_pad(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_PAD_DATA);
    return Data;
}

void XConv_ip_Set_groups(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_GROUPS_DATA, Data);
}

u32 XConv_ip_Get_groups(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_GROUPS_DATA);
    return Data;
}

void XConv_ip_Set_zp_in(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_ZP_IN_DATA, Data);
}

u32 XConv_ip_Get_zp_in(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_ZP_IN_DATA);
    return Data;
}

void XConv_ip_Set_inv_s_out(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_INV_S_OUT_DATA, Data);
}

u32 XConv_ip_Get_inv_s_out(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_INV_S_OUT_DATA);
    return Data;
}

void XConv_ip_Set_zp_out(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_ZP_OUT_DATA, Data);
}

u32 XConv_ip_Get_zp_out(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_ZP_OUT_DATA);
    return Data;
}

void XConv_ip_Set_silu(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_SILU_DATA, Data);
}

u32 XConv_ip_Get_silu(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_SILU_DATA);
    return Data;
}

void XConv_ip_Set_raw_out(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_RAW_OUT_DATA, Data);
}

u32 XConv_ip_Get_raw_out(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_RAW_OUT_DATA);
    return Data;
}

void XConv_ip_InterruptGlobalEnable(XConv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_GIE, 1);
}

void XConv_ip_InterruptGlobalDisable(XConv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_GIE, 0);
}

void XConv_ip_InterruptEnable(XConv_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_IER);
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_IER, Register | Mask);
}

void XConv_ip_InterruptDisable(XConv_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_IER);
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XConv_ip_InterruptClear(XConv_ip *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_ISR, Mask);
}

u32 XConv_ip_InterruptGetEnabled(XConv_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_IER);
}

u32 XConv_ip_InterruptGetStatus(XConv_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_ISR);
}

