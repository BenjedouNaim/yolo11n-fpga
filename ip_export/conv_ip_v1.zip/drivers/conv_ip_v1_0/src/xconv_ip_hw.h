// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of in_r
//        bit 31~0 - in_r[31:0] (Read/Write)
// 0x14 : Data signal of in_r
//        bit 31~0 - in_r[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of wgt
//        bit 31~0 - wgt[31:0] (Read/Write)
// 0x20 : Data signal of wgt
//        bit 31~0 - wgt[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of bias
//        bit 31~0 - bias[31:0] (Read/Write)
// 0x2c : Data signal of bias
//        bit 31~0 - bias[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of mult
//        bit 31~0 - mult[31:0] (Read/Write)
// 0x38 : Data signal of mult
//        bit 31~0 - mult[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of out8
//        bit 31~0 - out8[31:0] (Read/Write)
// 0x44 : Data signal of out8
//        bit 31~0 - out8[63:32] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of out32
//        bit 31~0 - out32[31:0] (Read/Write)
// 0x50 : Data signal of out32
//        bit 31~0 - out32[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of c_in
//        bit 31~0 - c_in[31:0] (Read/Write)
// 0x5c : reserved
// 0x60 : Data signal of h
//        bit 31~0 - h[31:0] (Read/Write)
// 0x64 : reserved
// 0x68 : Data signal of w
//        bit 31~0 - w[31:0] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of c_out
//        bit 31~0 - c_out[31:0] (Read/Write)
// 0x74 : reserved
// 0x78 : Data signal of k
//        bit 31~0 - k[31:0] (Read/Write)
// 0x7c : reserved
// 0x80 : Data signal of stride
//        bit 31~0 - stride[31:0] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of pad
//        bit 31~0 - pad[31:0] (Read/Write)
// 0x8c : reserved
// 0x90 : Data signal of groups
//        bit 31~0 - groups[31:0] (Read/Write)
// 0x94 : reserved
// 0x98 : Data signal of zp_in
//        bit 31~0 - zp_in[31:0] (Read/Write)
// 0x9c : reserved
// 0xa0 : Data signal of inv_s_out
//        bit 31~0 - inv_s_out[31:0] (Read/Write)
// 0xa4 : reserved
// 0xa8 : Data signal of zp_out
//        bit 31~0 - zp_out[31:0] (Read/Write)
// 0xac : reserved
// 0xb0 : Data signal of silu
//        bit 0  - silu[0] (Read/Write)
//        others - reserved
// 0xb4 : reserved
// 0xb8 : Data signal of raw_out
//        bit 0  - raw_out[0] (Read/Write)
//        others - reserved
// 0xbc : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCONV_IP_CONTROL_ADDR_AP_CTRL        0x00
#define XCONV_IP_CONTROL_ADDR_GIE            0x04
#define XCONV_IP_CONTROL_ADDR_IER            0x08
#define XCONV_IP_CONTROL_ADDR_ISR            0x0c
#define XCONV_IP_CONTROL_ADDR_IN_R_DATA      0x10
#define XCONV_IP_CONTROL_BITS_IN_R_DATA      64
#define XCONV_IP_CONTROL_ADDR_WGT_DATA       0x1c
#define XCONV_IP_CONTROL_BITS_WGT_DATA       64
#define XCONV_IP_CONTROL_ADDR_BIAS_DATA      0x28
#define XCONV_IP_CONTROL_BITS_BIAS_DATA      64
#define XCONV_IP_CONTROL_ADDR_MULT_DATA      0x34
#define XCONV_IP_CONTROL_BITS_MULT_DATA      64
#define XCONV_IP_CONTROL_ADDR_OUT8_DATA      0x40
#define XCONV_IP_CONTROL_BITS_OUT8_DATA      64
#define XCONV_IP_CONTROL_ADDR_OUT32_DATA     0x4c
#define XCONV_IP_CONTROL_BITS_OUT32_DATA     64
#define XCONV_IP_CONTROL_ADDR_C_IN_DATA      0x58
#define XCONV_IP_CONTROL_BITS_C_IN_DATA      32
#define XCONV_IP_CONTROL_ADDR_H_DATA         0x60
#define XCONV_IP_CONTROL_BITS_H_DATA         32
#define XCONV_IP_CONTROL_ADDR_W_DATA         0x68
#define XCONV_IP_CONTROL_BITS_W_DATA         32
#define XCONV_IP_CONTROL_ADDR_C_OUT_DATA     0x70
#define XCONV_IP_CONTROL_BITS_C_OUT_DATA     32
#define XCONV_IP_CONTROL_ADDR_K_DATA         0x78
#define XCONV_IP_CONTROL_BITS_K_DATA         32
#define XCONV_IP_CONTROL_ADDR_STRIDE_DATA    0x80
#define XCONV_IP_CONTROL_BITS_STRIDE_DATA    32
#define XCONV_IP_CONTROL_ADDR_PAD_DATA       0x88
#define XCONV_IP_CONTROL_BITS_PAD_DATA       32
#define XCONV_IP_CONTROL_ADDR_GROUPS_DATA    0x90
#define XCONV_IP_CONTROL_BITS_GROUPS_DATA    32
#define XCONV_IP_CONTROL_ADDR_ZP_IN_DATA     0x98
#define XCONV_IP_CONTROL_BITS_ZP_IN_DATA     32
#define XCONV_IP_CONTROL_ADDR_INV_S_OUT_DATA 0xa0
#define XCONV_IP_CONTROL_BITS_INV_S_OUT_DATA 32
#define XCONV_IP_CONTROL_ADDR_ZP_OUT_DATA    0xa8
#define XCONV_IP_CONTROL_BITS_ZP_OUT_DATA    32
#define XCONV_IP_CONTROL_ADDR_SILU_DATA      0xb0
#define XCONV_IP_CONTROL_BITS_SILU_DATA      1
#define XCONV_IP_CONTROL_ADDR_RAW_OUT_DATA   0xb8
#define XCONV_IP_CONTROL_BITS_RAW_OUT_DATA   1

